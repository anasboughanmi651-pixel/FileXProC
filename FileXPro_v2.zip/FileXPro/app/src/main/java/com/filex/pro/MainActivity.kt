package com.filex.pro

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.IntentCompat
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext

class MainActivity : ComponentActivity() {
    private var incoming by mutableStateOf<List<Uri>>(emptyList())

    override fun attachBaseContext(newBase: Context) {
        super.attachBaseContext(Loc.wrap(newBase))
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT)
        )
        handleIntent(intent)
        setContent {
            FXTheme {
                App(incoming, { incoming = emptyList() }, { recreate() })
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleIntent(intent)
    }

    override fun onStart() {
        super.onStart()
        TransferService.appVisible = true
    }

    override fun onStop() {
        super.onStop()
        TransferService.appVisible = false
    }

    private fun handleIntent(i: Intent?) {
        if (i == null) return
        val list = ArrayList<Uri>()
        when (i.action) {
            Intent.ACTION_SEND ->
                IntentCompat.getParcelableExtra(i, Intent.EXTRA_STREAM, Uri::class.java)?.let { list.add(it) }
            Intent.ACTION_SEND_MULTIPLE ->
                IntentCompat.getParcelableArrayListExtra(i, Intent.EXTRA_STREAM, Uri::class.java)?.let { list.addAll(it) }
        }
        if (list.isNotEmpty()) incoming = list
    }
}

enum class Screen { Splash, Main, Pick, Send, Receive, Privacy }

@Composable
fun Splash(onDone: () -> Unit) {
    val a = remember { Animatable(0f) }
    LaunchedEffect(Unit) {
        a.animateTo(1f, tween(800))
        delay(900)
        onDone()
    }
    Box(Modifier.fillMaxSize()) {
        Column(
            Modifier.fillMaxSize().alpha(a.value).scale(0.85f + 0.15f * a.value),
            verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Image(painterResource(R.drawable.filex_icon), null, Modifier.size(112.dp).clip(RoundedCornerShape(28.dp)))
            Spacer(Modifier.height(18.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                CrownIcon(30.dp)
                Spacer(Modifier.width(8.dp))
                Text("FileX Pro", color = Color.White, fontSize = 32.sp, fontWeight = FontWeight.ExtraBold)
            }
            Spacer(Modifier.height(6.dp))
            Text(stringResource(R.string.tagline), color = C.Lo, fontSize = 14.sp)
        }
        Signature(Modifier.align(Alignment.BottomCenter))
    }
}

@Composable
fun App(incoming: List<Uri>, onIncomingHandled: () -> Unit, onRecreate: () -> Unit) {
    val ctx = LocalContext.current
    var screen by remember { mutableStateOf(Screen.Splash) }
    var nav by remember { mutableIntStateOf(0) }
    var tab by remember { mutableIntStateOf(0) }
    val picked = remember { mutableStateListOf<PickedFile>() }

    LaunchedEffect(incoming) {
        if (incoming.isNotEmpty()) {
            val files = withContext(Dispatchers.IO) { incoming.map { Engine.queryFile(ctx, it) } }
            val have = picked.map { it.uri }.toHashSet()
            files.forEach { if (it.uri !in have) picked.add(it) }
            onIncomingHandled()
            tab = 1
            screen = Screen.Pick
        }
    }

    fun startSend() {
        Engine.startSending(ctx, picked.toList())
        screen = Screen.Send
    }

    fun shareApp() {
        picked.clear()
        picked.addAll(MediaRepo.selfApk(ctx))
        if (picked.isNotEmpty()) startSend()
    }

    BackHandler(enabled = screen == Screen.Pick || screen == Screen.Privacy) {
        if (screen == Screen.Pick) {
            picked.clear()
            screen = Screen.Main
        } else {
            nav = 2
            screen = Screen.Main
        }
    }

    AppBackground {
        Box(Modifier.fillMaxSize().systemBarsPadding(), contentAlignment = Alignment.TopCenter) {
            Box(Modifier.fillMaxHeight().widthIn(max = 600.dp).fillMaxWidth()) {
                Crossfade(targetState = screen, animationSpec = tween(220), label = "nav") { s ->
                    when (s) {
                        Screen.Splash -> Splash {
                            if (screen == Screen.Splash) {
                                screen = when {
                                    Engine.recvState.value.busy -> Screen.Receive
                                    Engine.sendState.value.busy -> Screen.Send
                                    else -> Screen.Main
                                }
                            }
                        }
                        Screen.Main -> Column(Modifier.fillMaxSize()) {
                            Box(Modifier.weight(1f)) {
                                when (nav) {
                                    0 -> HomeScreen(
                                        onSend = { picked.clear(); tab = 0; screen = Screen.Pick },
                                        onReceive = { screen = Screen.Receive },
                                        onTool = { t -> picked.clear(); tab = t; screen = Screen.Pick },
                                        onShareApp = { shareApp() }
                                    )
                                    1 -> HistoryScreen()
                                    else -> SettingsScreen(
                                        onPrivacy = { screen = Screen.Privacy },
                                        onShareApp = { shareApp() },
                                        onLanguageChanged = onRecreate
                                    )
                                }
                            }
                            FxNavBar(nav) { nav = it }
                        }
                        Screen.Pick -> PickScreen(
                            tab, { tab = it }, picked,
                            onBack = { picked.clear(); screen = Screen.Main },
                            onSend = { startSend() }
                        )
                        Screen.Send -> SendScreen(
                            onClose = { picked.clear(); screen = Screen.Main },
                            onBackToPick = { screen = if (picked.isEmpty()) Screen.Main else Screen.Pick },
                            onRetry = { if (picked.isNotEmpty()) startSend() else screen = Screen.Main }
                        )
                        Screen.Receive -> ReceiveScreen(onClose = { screen = Screen.Main })
                        Screen.Privacy -> PrivacyScreen(onBack = { nav = 2; screen = Screen.Main })
                    }
                }
            }
        }
    }
}
