package com.filex.pro

import android.net.Uri
import androidx.annotation.StringRes

const val SRC_MEDIA = 0
const val SRC_DOC = 1
const val SRC_APP = 2

data class PickedFile(
    val uri: Uri,
    val name: String,
    val size: Long,
    val mime: String,
    val source: Int = SRC_DOC
)

/** رسالة خطأ قابلة للترجمة (مورد نصي + معطى اختياري) */
class ErrInfo(@StringRes val res: Int, val arg: String? = null)

enum class Phase { Idle, Preparing, Waiting, Transferring, Done, Failed }

data class TransferState(
    val phase: Phase = Phase.Idle,
    val error: ErrInfo? = null,
    val names: List<String> = emptyList(),
    val sizes: List<Long> = emptyList(),
    val totalBytes: Long = 0,
    val doneBytes: Long = 0,
    val currentIndex: Int = 0,
    val failed: Set<Int> = emptySet(),
    val speedBps: Double = 0.0,
    val peerName: String = "",
    val verified: Int = 0,
    val mismatched: Int = 0,
    val startedAt: Long = 0L,
    val finishedAt: Long = 0L
) {
    val percent: Float
        get() = if (totalBytes > 0) (doneBytes.toDouble() / totalBytes).toFloat().coerceIn(0f, 1f) else 0f
    val remainingSec: Long
        get() = if (speedBps > 1) ((totalBytes - doneBytes) / speedBps).toLong() else -1L
    val busy: Boolean
        get() = phase == Phase.Preparing || phase == Phase.Waiting || phase == Phase.Transferring
    val fileCount: Int
        get() = names.size
    val durationSec: Long
        get() = if (startedAt > 0 && finishedAt >= startedAt) (finishedAt - startedAt) / 1000 else 0L
}

data class HistoryItem(
    val time: Long,
    val dir: String,
    val count: Int,
    val bytes: Long,
    val ok: Boolean,
    val peer: String,
    val durationSec: Long
)

data class MediaItem(
    val id: Long,
    val uri: Uri,
    val name: String,
    val size: Long,
    val mime: String,
    val video: Boolean,
    val durationMs: Long
)

data class AppItem(
    val pkg: String,
    val label: String,
    val size: Long,
    val files: List<PickedFile>
)
