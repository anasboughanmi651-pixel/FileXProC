package com.filex.pro

import java.io.InputStream
import java.security.SecureRandom
import javax.crypto.Cipher
import javax.crypto.spec.IvParameterSpec
import javax.crypto.spec.SecretKeySpec

/**
 * تشفير AES-128-CTR. المفتاح و nonce ينتقلوا فقط داخل QR (قناة خارج الشبكة).
 * كل ملف له IV مختلف: ملف i => 2*i ، مجموع SHA-256 متاعو => 2*i+1 ، القائمة => -1
 */
object Crypto {
    const val LIST_IDX = -1

    fun fileIdx(i: Int) = i * 2
    fun sumIdx(i: Int) = i * 2 + 1

    fun newKey(): ByteArray = ByteArray(16).also { SecureRandom().nextBytes(it) }
    fun newNonce(): ByteArray = ByteArray(8).also { SecureRandom().nextBytes(it) }

    private fun iv(nonce: ByteArray, index: Int): IvParameterSpec {
        val b = ByteArray(16)
        System.arraycopy(nonce, 0, b, 0, 8)
        b[8] = (index ushr 24).toByte()
        b[9] = (index ushr 16).toByte()
        b[10] = (index ushr 8).toByte()
        b[11] = index.toByte()
        return IvParameterSpec(b)
    }

    fun cipher(mode: Int, key: ByteArray, nonce: ByteArray, index: Int): Cipher {
        val c = Cipher.getInstance("AES/CTR/NoPadding")
        c.init(mode, SecretKeySpec(key, "AES"), iv(nonce, index))
        return c
    }

    fun encryptBytes(data: ByteArray, key: ByteArray, nonce: ByteArray, index: Int): ByteArray =
        cipher(Cipher.ENCRYPT_MODE, key, nonce, index).doFinal(data)

    fun decryptBytes(data: ByteArray, key: ByteArray, nonce: ByteArray, index: Int): ByteArray =
        cipher(Cipher.DECRYPT_MODE, key, nonce, index).doFinal(data)

    fun hex(b: ByteArray): String = b.joinToString("") { "%02x".format(it) }

    fun unhex(s: String): ByteArray {
        if (s.length % 2 != 0) throw IllegalArgumentException("bad hex")
        return ByteArray(s.length / 2) { i -> s.substring(i * 2, i * 2 + 2).toInt(16).toByte() }
    }
}

/** تيار تشفير سريع (بلوكات 64KB) - أسرع بكثير من CipherInputStream (512B) */
class CtrStream(private val src: InputStream, private val cipher: Cipher) : InputStream() {
    private val inBuf = ByteArray(64 * 1024)
    private val outBuf = ByteArray(64 * 1024)
    private var pos = 0
    private var lim = 0
    private var eof = false

    private fun fill(): Boolean {
        while (!eof) {
            val n = src.read(inBuf, 0, inBuf.size)
            if (n < 0) {
                eof = true
                return false
            }
            if (n == 0) continue
            val o = cipher.update(inBuf, 0, n, outBuf, 0)
            if (o > 0) {
                pos = 0
                lim = o
                return true
            }
        }
        return false
    }

    override fun read(): Int {
        if (pos >= lim && !fill()) return -1
        return outBuf[pos++].toInt() and 0xff
    }

    override fun read(b: ByteArray, off: Int, len: Int): Int {
        if (len == 0) return 0
        if (pos >= lim && !fill()) return -1
        val n = minOf(len, lim - pos)
        System.arraycopy(outBuf, pos, b, off, n)
        pos += n
        return n
    }

    override fun available(): Int = lim - pos

    override fun close() {
        src.close()
    }
}
