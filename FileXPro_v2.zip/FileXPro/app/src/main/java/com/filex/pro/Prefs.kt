package com.filex.pro

import android.content.Context
import android.content.res.Configuration
import android.os.Build
import java.util.Locale

object Prefs {
    private fun sp(ctx: Context) = ctx.getSharedPreferences("filex", Context.MODE_PRIVATE)

    fun deviceName(ctx: Context): String {
        val v = sp(ctx).getString("device", null)
        if (!v.isNullOrBlank()) return v
        return Build.MODEL ?: "Android"
    }

    fun setDeviceName(ctx: Context, v: String) {
        sp(ctx).edit().putString("device", v.trim().take(32)).apply()
    }

    /** "" = لغة النظام ، أو ar / en / fr */
    fun lang(ctx: Context): String = sp(ctx).getString("lang", "") ?: ""

    fun setLang(ctx: Context, code: String) {
        sp(ctx).edit().putString("lang", code).apply()
    }

    fun notifAsked(ctx: Context): Boolean = sp(ctx).getBoolean("notif_asked", false)

    fun setNotifAsked(ctx: Context) {
        sp(ctx).edit().putBoolean("notif_asked", true).apply()
    }
}

object Loc {
    fun wrap(base: Context): Context {
        val lang = Prefs.lang(base)
        if (lang.isEmpty()) return base
        val locale = Locale(lang)
        Locale.setDefault(locale)
        val cfg = Configuration(base.resources.configuration)
        cfg.setLocale(locale)
        return base.createConfigurationContext(cfg)
    }
}
